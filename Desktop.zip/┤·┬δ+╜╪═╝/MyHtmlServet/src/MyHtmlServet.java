import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.InterruptedIOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;

import javax.xml.crypto.Data;
 
public class MyHtmlServet {
	
	public static void main(String[] args) throws IOException {
		int port=80;
		if(args.length>0)
			port=Integer.valueOf(args[0]);
		new MyHtmlServet().start(port);
 
	}
	
	/**
	 * ��ָ���˿�����http������
	 * @param port ָ���Ķ˿�
	 * @throws IOException
	 * 
	 */
	public void start(int port) throws IOException {
		ServerSocket server = new ServerSocket(port);
		System.out.println("server start at "+port+"...........");
		//System.out.println(server.getChannel().toString());
		while (true) {
			Socket client = server.accept();
			ServerThread serverthread = new ServerThread( client);
			serverthread.start();
		}
	}
	
	/**
	 * ��������Ӧ�̣߳�ÿ�յ�һ�������������ͻ�����һ��ServerThread�߳�
	 * @author 
	 *
	 */
	class ServerThread extends Thread {
		Socket client;
 
		public ServerThread(Socket client) {
			this.client = client;
		}
		
		/**
		 * ��ȡ�ļ����ݣ�ת��Ϊbyte����
		 * @param filename �ļ���
		 * @return
		 * @throws IOException
		 */
		public  byte[] getFileByte(String filename) throws IOException
		{
			ByteArrayOutputStream baos=new ByteArrayOutputStream();
			File file=new File(filename);
			FileInputStream fis=new FileInputStream(file);
			byte[] b=new byte[1000];
			int read;
			while((read=fis.read(b))!=-1)
			{
				baos.write(b,0,read);
			}
			fis.close();
			baos.close();
			return baos.toByteArray();
		}
 
		
		/**
		 * ����http�����е�url,�����û��������Դ����������url�淶��
		 * �������� "/"Ҫ�淶��"/index.html","/index"Ҫ�淶��"/index.html"
		 * @param queryurl �û�ԭʼ��url
		 * @return �淶����url����Ϊ�û�������Դ��·��
		 */
		private String getQueryResource(String queryurl)
		{
			String queryresource=null;
			int index=queryurl.indexOf('?');
			if(index!=-1)
			{
				queryresource=queryurl.substring(0,queryurl.indexOf('?'));
			}
			else
				queryresource=queryurl;
			
			index=queryresource.lastIndexOf("/");
			if(index+1==queryresource.length())
			{
				queryresource=queryresource+"index.html";
			}
			else
			{
				String filename=queryresource.substring(index+1);
				if(!filename.contains("."))
					queryresource=queryresource+".html";
			}			
			return queryresource;
 
		}
		
	
		/**
		 * �����û��������Դ���ͣ��趨http��Ӧͷ����Ϣ����Ҫ���ж��û�������ļ����ͣ�html��jpg...��
		 * @param queryresource
		 * @return
		 */
		private String getHead(String queryresource)
		{
			String filename="";
			int index=queryresource.lastIndexOf("/");
			filename=queryresource.substring(index+1);
			String[] filetypes=filename.split("\\.");
			String filetype=filetypes[filetypes.length-1];
			if(filetype.equals("html"))
			{
				return "HTTP/1.0200OK\n"+"Content-Type:text/html\n" + "Server:myserver\n" + "\n";
			}
			else if(filetype.equals("jpg")||filetype.equals("gif")||filetype.equals("png"))
			{
				return "HTTP/1.0200OK\n"+"Content-Type:image/jpeg\n" + "Server:myserver\n" + "\n";
			}
			else if(filetype.equals("js"))
			{
				return "HTTP/1.0200OK\n"+"Content-Type:application/x-javascript\n" + "Server:myserver\n" + "\n";
			}
			else if(filetype.equals("css"))
			{
				return "HTTP/1.0200OK\n"+"Content-Type:text/css\n" + "Server:myserver\n" + "\n";
			}
			else if(filetype.equals("txt"))
			{
				return "HTTP/1.0200OK\n"+"Content-Type:txt\n" + "Server:myserver\n" + "\n";
			}
			else return null;
			
		}
 
		@Override
		public void run() {
			InputStream is;
			try {
				is = client.getInputStream();
				System.out.println("1"+client.getInetAddress().toString());
				BufferedReader br = new BufferedReader(
						new InputStreamReader(is));
				int readint;
				char c;
				byte[] buf = new byte[1000];
				OutputStream os = client.getOutputStream();
				
				client.setSoTimeout(50);
				byte[] data = null;
				String cmd = "";
				String queryurl = "";
				int state = 0;
				String queryresource;
				String head;
				while (true) {
					readint = is.read();
					c = (char) readint;
					boolean space=Character.isWhitespace(readint);
					switch (state) {
						case 0:
							if (space)
								continue;
							state = 1;
						case 1:
							if (space) {
								state=2;
								continue;
							}
							cmd+=c;
							continue;
						case 2:
							if(space)
								continue;
							state=3;
						case 3:
							if(space)
								break;
							queryurl+=c;
							continue;
						}
					break;
				}
				
				queryresource=getQueryResource(queryurl);
				head=getHead(queryresource);
 
				while (true) {
					int test=1;
					try {
						if ((readint = is.read(buf)) > 0) {
						//	System.out.write(buf);
						} else if (readint < 0)
							break;
					} catch (InterruptedIOException e) {
						int index=queryresource.lastIndexOf("/");
						System.out.println(queryresource);
						if(index!=0){
							if(queryresource.contains("X")){
								data="1".getBytes();
								String test1=null;
								int firstindex,lastindex;
								firstindex=queryresource.lastIndexOf("d")+1;
								lastindex=queryresource.lastIndexOf(".");
								String number=queryresource.substring(firstindex, lastindex);
					
								int datass=Integer.parseInt(number);
								if(0<=datass&&datass<=20){
									test1="ŵ�������������";
									//test1="The Nobel Prize";
								}
								if(20<datass&&datass<=30){
									//test1="Next Xin Xiaodai";
									test1="��һ����С��";
								}
								if(30<datass&&datass<=40){
									//test1="Tencent offer +1%";
									test1="��Ѷoffer����+1%";
								}
								if(40<datass&&datass<=55){
									//test1="Never failed exam";
									test1="�����ҿ�!";
								}
								if(55<datass&&datass<=65){
									//test1="Dinner with Ma Yun";
									test1="��������ƹ������͵Ļ���!";
									
								}
								if(65<datass&&datass<=80){
									//test1="Exemption from cet-4 and cet-6";
									test1="�⿼������!";
									
								}
								if(80<datass&&datass<=95){
									//test1="Happy New Year 2019";
									test1="��ǰף��2019�������!";
								}
								if(95<datass&&datass<=100){
									//test1="Go to the top of life";
									test1="���������۷�!";
								}
								FileOutputStream fos = new FileOutputStream("bin/award.txt",true); 
						        @SuppressWarnings("resource")
								OutputStreamWriter osw = new OutputStreamWriter(fos, "UTF-8"); 
						        Date a=new Date();
						        osw.write(client.getInetAddress().toString()+"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+a.toString()+"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+test1+"<br>");
						     
						        osw.flush(); 
						
								/*
								FileWriter fw = null;
								try {
									//����ļ����ڣ���׷�����ݣ�����ļ������ڣ��򴴽��ļ�
									File f=new File("bin/award.txt");
									fw = new FileWriter(f, true);
									} catch (IOException x) {
									x.printStackTrace();
									}
								Date a=new Date();
								PrintWriter pw = new PrintWriter(fw);
								pw.println("ip:"+client.getInetAddress().toString()+" time:"+a.toString()+"="+test1);
								pw.flush();
								try {
								fw.flush();
								pw.close();
								fw.close();
								} catch (IOException f) {
								f.printStackTrace();
								}*/
							}
							
							else{
								FileWriter fw = null;
								data=getFileByte(queryresource.substring(1,queryresource.length() ));
							}
						}
						else
						data = getFileByte("webapp"+queryresource);
					}
					if(data=="1".getBytes()){
						break;
					}
					if (data != null) {
						os.write(head.getBytes("utf-8"));
						os.write(data);
						os.close();
						break;
					}
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
 
		}
	}
}
