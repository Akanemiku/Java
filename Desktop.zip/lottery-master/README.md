# lottery
### 比较常用的几种抽奖效果
--------

[跑马灯](https://areyouse7en.github.io/lottery/lottery.marquee.html) 
[扑克牌翻转](https://areyouse7en.github.io/lottery/lottery.poker.html) 